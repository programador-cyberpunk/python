from spire.xls import *

#isso deve ser pra pegar todo tipo de planilha ou arquivo de dado
Workbook = Workbook()

Workbook.LoadFromFile("E:\ler_bagulhos\acompanhamento-daexecusao-fisico-financeira-das-obras-publicas-de-ferrivias.xlsx")
#pega o indice zero eu acho
sheet = Workbook.Worksheets[0]

sheet.SaveToFile("E:\ler_bagulhos\acompanhamento-daexecusao-fisico-financeira-das-obras-publicas-de-ferrivias.csv", ",", Encoding.get_UTF8() workbook.Dispose()")
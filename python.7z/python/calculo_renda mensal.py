# primeiro vamo calcula os bagulho e eu sou ruim de matematica

def calcular_imposto(renda_mensal):
    if renda_mensal <=2586.45:
        return 0
    elif renda_mensal <=19800.00:
        return renda_mensal * 0.17
    else: 
        return renda_mensal * 0.25   

 # um caso de uso agora

 renda = float(input("Digite ai sua renda: R$ "))
 imposto = calcular_imposto(renda)
 print(f"O valor do imposto pago eh: R$ {imposto:..2f}")
 if renda <=2586.45:
    print("Vc ta isento de imposto,seu fudido")   
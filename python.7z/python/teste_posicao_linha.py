def sei_la(a, b, c):
    print("Salve ximira")
    print("To tentando ler a tela ma ta foda")
    print("realmnte, ta embassado")
    print("Nao da pa ler foda-se")
    
print("eu to fora dessa porra")    

def mes(index):
    lista = ("janeiro", "fevereiro", "marco", "abril", "maio")


nome = nome_mes(2)
print(nome)    
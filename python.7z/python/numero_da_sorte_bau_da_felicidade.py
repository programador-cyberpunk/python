#vamo definir os bagulho antes

def veriica_numero(lista, numero):
    return numero in lista

numero = [1,7,4,3,2,0,5,8,2,6,9]
verifica(int(input("Digite um numero ai: ")))
if verifica_numero(numero,verifica):
    print(f"O numero {verifica} esta na lista")
else:
    print(f"O numero {verifica} nao esta na lista")
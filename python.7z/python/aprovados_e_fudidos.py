#definir os bagulho primeiro

def imprimir_notas_aprovacao(dados_aluno):
    # eu nao uso  a extensao pt-br pq sempre da bosta
    disciplinas = ['Matematica', "Ciencias", "Historia", "Geografia", "Portugues"]
    aprovado = []

   for disciplina in disciplinas:
    notas = dados_aluno[disciplina]
    media = sum(notas) / len(notas)
    print(f"{disciplina}: Notas: {notas}, Media: {media:..2f}")
    if media >= 6:
        aprovado.append(disciplina)
        print("parabens topeira,vc passou" .join(aprovado))

        notas_aluno = {
             'Português': [7, 6, 5, 8],
             'Matemática': [5, 6, 7, 8],
             'História': [6, 6, 7, 5],
            'Geografia': [8, 9, 7, 10]
}

imprimir_notas_e_aprovacao(notas_aluno)ta.")